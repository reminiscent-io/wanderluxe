import type { Express } from "express";
import { IVerifyOptions } from "passport-local";
import passport from "passport";
import { db } from "@db";
import { users, insertUserSchema, type User } from "@db/schema";
import { eq } from "drizzle-orm";
import { crypto } from "./passport";
import { requireAuth } from "../middleware/auth.middleware";

// Create test user
const createTestUser = async () => {
  try {
    const [existingUser] = await db
      .select()
      .from(users)
      .where(eq(users.username, 'test'))
      .limit(1);

    if (!existingUser) {
      const hashedPassword = await crypto.hash('test');
      await db.insert(users).values({
        username: 'test',
        password: hashedPassword,
      });
      console.log('Test user created successfully');
    }
  } catch (error) {
    console.error('Error creating test user:', error);
  }
};

export function setupAuthRoutes(app: Express) {
  // Create test user on startup
  createTestUser();

  app.post("/api/register", async (req, res, next) => {
    try {
      const { username, password } = req.body;

      if (!username?.trim() || !password?.trim()) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const [existingUser] = await db
        .select()
        .from(users)
        .where(eq(users.username, username.trim()))
        .limit(1);

      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await crypto.hash(password.trim());

      const [newUser] = await db
        .insert(users)
        .values({
          username: username.trim(),
          password: hashedPassword,
        })
        .returning();

      req.login(newUser, (err) => {
        if (err) return next(err);
        return res.json({
          id: newUser.id,
          username: newUser.username,
        });
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: User, info: IVerifyOptions) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info.message || "Authentication failed" });
      }

      req.login(user, (err) => {
        if (err) return next(err);
        return res.json({
          id: user.id,
          username: user.username,
        });
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/user", requireAuth, (req, res) => {
    const user = req.user as User;
    res.json({
      id: user.id,
      username: user.username,
    });
  });
}